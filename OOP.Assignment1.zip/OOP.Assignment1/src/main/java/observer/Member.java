package observer;

public interface Member {
        public void update(UndoableStringBuilder usb);
}
